import numpy as np
from sklearn.tree import DecisionTreeClassifier
import joblib

# Step 1: Generate random training data (simulating high-voltage lines)
np.random.seed(42)  # For reproducibility
n_samples = 1000
voltage = np.random.uniform(180, 260, n_samples)  # Voltage in kV (e.g., 180-260 kV range)
current = np.random.uniform(400, 1200, n_samples)  # Current in A (e.g., 400-1200 A range)

# Step 2: Define standard thresholds (hypothetical, adjust as needed)
V_MIN, V_MAX = 220, 240  # kV
I_MIN, I_MAX = 500, 1000  # A

# Step 3: Create labels based on thresholds
labels = []
for v, i in zip(voltage, current):
    v_status = "NORMAL VOLTAGE" if V_MIN <= v <= V_MAX else "UNDER VOLTAGE" if v < V_MIN else "OVER VOLTAGE"
    i_status = "NORMAL CURRENT" if I_MIN <= i <= I_MAX else "UNDER CURRENT" if i < I_MIN else "OVER CURRENT"
    labels.append(f"{v_status} AND {i_status}")

# Features (voltage, current) and labels
X = np.column_stack((voltage, current))
y = np.array(labels)

# Step 4: Train the DecisionTreeClassifier
clf = DecisionTreeClassifier(max_depth=5)
clf.fit(X, y)

# Step 5: Save the model to Joblib
joblib.dump(clf, 'hv_transmission_model.joblib')
print("Model saved as 'hv_transmission_model.joblib'")

# Step 6: Test with new data
test_voltage = [210, 230, 250]  # kV
test_current = [450, 800, 1100]  # A
test_data = np.column_stack((test_voltage, test_current))

# Load model (if needed) and predict
predictions = clf.predict(test_data)
for v, i, pred in zip(test_voltage, test_current, predictions):
    print(f"Voltage: {v} kV, Current: {i} A -> {pred}")